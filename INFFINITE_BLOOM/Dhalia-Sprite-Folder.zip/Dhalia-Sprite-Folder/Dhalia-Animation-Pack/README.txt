Dhalia animation prototype pack
Transparent PNG frames + GIF previews.
Stage 1: idle, plant attack, growth, hurt.
Stage 2: idle, sword attack, shield, hurt.
Stage 3: idle, sword attack, shield, hurt, Blooming.
These animate the approved single-pose sprites with transforms/effects; true limb articulation needs extra poses/frames.